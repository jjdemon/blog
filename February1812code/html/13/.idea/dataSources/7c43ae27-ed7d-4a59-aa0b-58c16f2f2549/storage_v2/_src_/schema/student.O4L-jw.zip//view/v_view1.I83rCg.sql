create definer = root@localhost view v_view1 as
select `s`.`sno`       AS `sno`,
       `s`.`sname`     AS `sname`,
       `s`.`ssex`      AS `ssex`,
       `s`.`sbirthday` AS `sbirthday`,
       `s`.`class`     AS `class`,
       `c`.`cno`       AS `cno`,
       `c`.`cname`     AS `cname`,
       `c`.`tno`       AS `tno`,
       `g`.`degree`    AS `degree`
from `student`.`student` `s`
       join `student`.`course` `c`
       join `student`.`grade` `g`
where ((`g`.`cno` = `c`.`cno`) and (`s`.`sno` = `g`.`sno`));

