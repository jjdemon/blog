create definer = root@localhost view v_student as
select `student`.`student`.`sno`   AS `sno`,
       `student`.`student`.`sname` AS `name`,
       `student`.`student`.`class` AS `sclass`
from `student`.`student`;

